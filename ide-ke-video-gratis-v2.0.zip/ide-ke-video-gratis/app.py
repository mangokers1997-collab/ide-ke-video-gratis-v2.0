from flask import Flask, render_template, request, send_file, flash, redirect, url_for, make_response
from PIL import Image, ImageDraw, ImageFont
import imageio_ffmpeg
import tempfile, os, textwrap, random, re, subprocess, json, html

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'ide-video-v2-local-key')

TOPICS = {
    'Personal Finance': ['5 kebiasaan kecil yang bikin uang cepat habis', 'Cara membuat anggaran bulanan sederhana', 'Dana darurat: mulai dari nominal kecil', 'Kesalahan mengatur gaji pertama', 'Bedakan kebutuhan dan keinginan', 'Cara mengatur uang saat penghasilan tidak tetap'],
    'Psikologi Uang': ['Kenapa kita sering belanja impulsif?', 'Efek gaya hidup ikut-ikutan pada keuangan', 'Cara membangun disiplin menabung', 'Mengatasi FOMO saat melihat investasi orang lain', 'Mengapa diskon membuat kita boros?'],
    'Crypto': ['Apa itu Bitcoin untuk pemula?', 'Blockchain dijelaskan dengan analogi sederhana', 'Perbedaan coin dan token', 'Cara mengenali penipuan kripto', 'Apa fungsi wallet kripto?'],
    'Trading & Risk': ['Apa arti risk/reward ratio?', 'Mengapa stop loss itu penting?', 'Jangan trading dengan uang kebutuhan', 'Cara membuat jurnal trading sederhana', 'Mengapa ukuran posisi sangat penting?'],
    'Investasi Dasar': ['Apa itu diversifikasi?', 'Investasi vs trading: apa bedanya?', 'Mengenal risiko dan imbal hasil', 'Mulai investasi dengan tujuan yang jelas', 'Apa itu compounding?']
}
HOOKS = ['Pernah merasa uang baru masuk, tapi tiba-tiba sudah habis?', 'Satu kesalahan kecil ini bisa mengganggu rencana keuanganmu.', 'Sebelum mengambil keputusan, pahami hal penting berikut.', 'Banyak orang melewatkan langkah sederhana ini.', 'Kalau kamu masih pemula, simak penjelasan singkat ini.']


def make_script(topic, audience, duration, tone):
    title = topic.strip() or random.choice(TOPICS['Personal Finance'])
    seconds = max(30, min(int(duration or 60), 600))
    hook = random.choice(HOOKS) + f' Kali ini kita membahas {title.lower()}.'
    style = {'Santai':'Bayangkan kamu sedang ngobrol dengan teman. ', 'Profesional':'Gunakan pendekatan yang terstruktur dan objektif. ', 'Edukasi':'Jelaskan konsep secara bertahap dengan bahasa sederhana. '}.get(tone, '')
    points = [
        f'Pertama, pahami konsep dasarnya. {title} perlu dilihat sesuai tujuan dan kondisi masing-masing, bukan sekadar mengikuti tren.',
        f'Kedua, lakukan langkah yang terukur. Untuk {audience.lower()}, mulailah dari hal sederhana: catat kondisi saat ini, tentukan target, lalu evaluasi secara berkala.',
        'Ketiga, perhatikan risiko dan batas kemampuan. Tidak ada metode yang selalu berhasil. Hindari keputusan terburu-buru dan jangan gunakan uang untuk kebutuhan pokok.',
        'Terakhir, buat kebiasaan yang konsisten. Kemajuan biasanya datang dari keputusan kecil yang dilakukan berulang, bukan dari jalan pintas.'
    ]
    if seconds <= 60: points = points[:3]
    outro = 'Kesimpulannya, pahami dulu sebelum bertindak dan sesuaikan keputusan dengan kondisi masing-masing. Konten ini bersifat edukasi, bukan nasihat keuangan pribadi. Like, komentar, dan subscribe untuk pembahasan berikutnya.'
    # Expand voiceover naturally for longer formats without pretending to be AI-generated.
    if seconds > 90:
        points += [
            'Contoh penerapannya: tuliskan tujuan yang ingin dicapai, pecah menjadi beberapa langkah kecil, dan tentukan kapan kamu akan meninjau hasilnya.',
            'Kesalahan yang perlu dihindari adalah membandingkan kondisi diri dengan orang lain. Setiap orang memiliki pendapatan, kebutuhan, dan toleransi risiko yang berbeda.'
        ]
    scenes = [hook] + points + [outro]
    return {'title':title, 'hook':hook, 'body':'\n\n'.join(points), 'outro':outro, 'full':'\n\n'.join(scenes), 'scenes':scenes, 'description':f'{title}. Pelajari konsep dasarnya, contoh penerapan, dan risiko yang perlu diperhatikan.\n\nKonten edukasi, bukan nasihat keuangan pribadi.', 'hashtags':'#finansial #edukasikeuangan #literasikeuangan #belajarinvestasi'}


def load_font(size, bold=False):
    paths = ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf' if bold else '/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf']
    for path in paths:
        if os.path.exists(path): return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def make_scene_image(title, text, idx, total, width, height, out_path):
    # Efficient vertical gradient background.
    top=(7, 20, 34); bottom=(17, 65, 73)
    im=Image.new('RGB',(width,height)); pix=im.load()
    for y in range(height):
        t=y/max(1,height-1); color=tuple(int(top[k]*(1-t)+bottom[k]*t) for k in range(3))
        for x in range(width): pix[x,y]=color
    d=ImageDraw.Draw(im)
    margin=int(width*.065); radius=max(18,int(width*.025))
    d.rounded_rectangle((margin,margin,width-margin,height-margin),radius=radius,outline=(75,190,174),width=max(2,width//500))
    compact=width < height
    brand_size=max(18,int(width*.025)); title_size=max(22,int(width*(.038 if compact else .032)))
    body_size=max(25,int(width*(.050 if compact else .043)))
    d.text((margin+int(width*.04),margin+int(height*.045)),'IDE → VIDEO GRATIS  •  V2.0',font=load_font(brand_size,True),fill=(115,235,211))
    title_lines=textwrap.wrap(title,width=max(18,int(width/(title_size*.62))))[:3]
    ty=margin+int(height*.12)
    for line in title_lines:
        d.text((margin+int(width*.04),ty),line,font=load_font(title_size,True),fill=(220,239,242)); ty+=int(title_size*1.3)
    max_chars=max(16,int(width/(body_size*.57)))
    lines=textwrap.wrap(text,max_chars)
    max_lines=7 if compact else 6
    if len(lines)>max_lines: lines=lines[:max_lines]; lines[-1]=lines[-1].rstrip(' .,')+'…'
    line_h=int(body_size*1.42); total_h=len(lines)*line_h
    y=max(ty+int(height*.06),(height-total_h)//2)
    for line in lines:
        bbox=d.textbbox((0,0),line,font=load_font(body_size,True)); x=(width-(bbox[2]-bbox[0]))//2
        d.text((x,y),line,font=load_font(body_size,True),fill=(255,255,255)); y+=line_h
    footer_y=height-margin-int(height*.075)
    d.text((margin+int(width*.04),footer_y),f'EDUKASI • SCENE {idx}/{total}',font=load_font(max(15,int(width*.019))),fill=(151,194,197))
    im.save(out_path,quality=92)


def render_video(title, scenes, out_path, ratio='16:9', scene_seconds=4):
    dimensions={'16:9':(1280,720),'9:16':(720,1280),'1:1':(900,900)}
    width,height=dimensions.get(ratio,dimensions['16:9'])
    ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
    with tempfile.TemporaryDirectory(prefix='idevideo_') as work:
        concat=os.path.join(work,'scenes.txt')
        with open(concat,'w',encoding='utf-8') as f:
            for i,scene in enumerate(scenes,1):
                image_path=os.path.join(work,f'scene_{i:03}.jpg')
                make_scene_image(title,scene,i,len(scenes),width,height,image_path)
                f.write(f"file '{image_path}'\n")
                f.write(f'duration {scene_seconds}\n')
            f.write(f"file '{os.path.join(work,f'scene_{len(scenes):03}.jpg')}'\n")
        cmd=[ffmpeg,'-y','-f','concat','-safe','0','-i',concat,'-vf','fps=24,format=yuv420p','-c:v','libx264','-preset','ultrafast','-crf','24','-movflags','+faststart',out_path]
        proc=subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
        if proc.returncode: raise RuntimeError(proc.stderr[-1000:])


@app.route('/', methods=['GET','POST'])
def index():
    result=None; selected='Personal Finance'
    if request.method=='POST':
        selected=request.form.get('category','Personal Finance')
        if selected not in TOPICS: selected='Personal Finance'
        topic=request.form.get('topic','').strip() or random.choice(TOPICS[selected])
        result=make_script(topic,request.form.get('audience','Pemula'),request.form.get('duration','60'),request.form.get('tone','Edukasi'))
    return render_template('index.html',topics=TOPICS,result=result,selected=selected)


@app.route('/video',methods=['POST'])
def video():
    title=request.form.get('title','Video edukasi').strip()[:180]
    scenes=[s.strip() for s in request.form.get('scenes','').split('\n---\n') if s.strip()]
    if not scenes:
        flash('Naskah kosong. Buat atau isi scene terlebih dahulu.'); return redirect(url_for('index'))
    if len(scenes)>30: flash('Maksimal 30 scene per video.'); return redirect(url_for('index'))
    ratio=request.form.get('ratio','16:9'); seconds=max(2,min(int(request.form.get('scene_seconds',4)),10))
    tmp=tempfile.NamedTemporaryFile(suffix='.mp4',delete=False); tmp.close()
    try:
        render_video(title,scenes,tmp.name,ratio,seconds)
        return send_file(tmp.name,as_attachment=True,download_name='ide-ke-video-v2.mp4',mimetype='video/mp4')
    except Exception as e:
        try: os.unlink(tmp.name)
        except OSError: pass
        flash('Gagal membuat video: '+str(e)); return redirect(url_for('index'))


@app.route('/health')
def health(): return {'status':'ok','version':'2.0.0'}

if __name__=='__main__':
    app.run(host='0.0.0.0',port=int(os.environ.get('PORT',8000)),debug=False)
