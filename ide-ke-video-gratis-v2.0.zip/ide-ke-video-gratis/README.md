# IDE → VIDEO GRATIS V2.0

Aplikasi web lokal untuk membuat ide konten, naskah, metadata YouTube, dan video slideshow MP4. Dibangun dengan Flask, Pillow, dan FFmpeg dari `imageio-ffmpeg`.

## Fitur
- Generator ide berdasarkan 5 kategori: Personal Finance, Psikologi Uang, Crypto, Trading & Risk, dan Investasi Dasar.
- Generator hook, naskah, deskripsi YouTube, dan hashtag.
- Pilihan durasi naskah 30 detik hingga 10 menit.
- Editor scene sebelum render.
- Export MP4 dengan rasio 16:9 (1280×720), 9:16 (720×1280), atau 1:1 (900×900).
- Pengaturan durasi per scene (2–10 detik), 24 FPS.
- Endpoint pemeriksaan `/health`.
- Tidak membutuhkan API key atau layanan AI berbayar.

## Catatan penting
Generator konten menggunakan template lokal, bukan AI generatif. Render menghasilkan slideshow teks dengan desain gradasi. V2.0 belum menyertakan voice-over/TTS, avatar, musik, stok footage, atau gambar AI. Tidak ada upload YouTube otomatis.

## Jalankan di GitHub Codespaces
1. Unggah seluruh isi folder repository ke GitHub.
2. Buka repository → **Code** → **Codespaces** → **Create codespace on main**.
3. Tunggu instalasi dependency dari `postCreateCommand` selesai. Jika belum, jalankan `pip install -r requirements.txt`.
4. Di terminal jalankan:
   ```bash
   python app.py
   ```
5. Buka tab **Ports**, pastikan port `8000` berstatus forwarded, lalu pilih **Open in Browser**.
6. Pilih kategori dan opsi, klik **Buat ide & naskah**. Jika perlu, edit scene, pilih rasio, lalu klik **Render & unduh MP4**.

## Jalankan di komputer
Python 3.10 atau lebih baru direkomendasikan.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Buka http://localhost:8000

## Struktur repository
```text
ide-ke-video-gratis/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── .devcontainer/
│   └── devcontainer.json
├── templates/
│   └── index.html
└── static/
    └── style.css
```

## Troubleshooting
- **Port 8000 tidak muncul:** buka tab Ports → Add Port → `8000`.
- **Render gagal:** jalankan `pip install -r requirements.txt`, lalu restart `python app.py`.
- **Video terlalu panjang:** kurangi jumlah scene atau durasi tiap scene.
- **Jangan commit file rahasia** seperti `.env` atau API key ke repository.

## Changelog V2.0
- UI diperbarui dan responsif untuk layar ponsel.
- Naskah dan metadata YouTube ditampilkan terpisah.
- Rasio video dan durasi scene dapat dipilih.
- Render scene memakai image sequence + FFmpeg concat agar tidak membuat frame satu per satu di Python.
- Server berjalan dengan debug nonaktif secara default.
